<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <title>الدفع - Rosmary Organic</title>
    <style>
        .btn-primary {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-primary:hover {
            background-color: #bb2d3b;
            border-color: #b02a37;
        }
        .btn-outline-primary {
            color: #dc3545;
            border-color: #dc3545;
        }
        .btn-outline-primary:hover {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .bg-primary {
            background-color: #dc3545 !important;
        }
        .text-primary {
            color: #dc3545 !important;
        }
        .form-check-input:checked {
            background-color: #dc3545;
            border-color: #dc3545;
        }
    </style>
</head>

<body>
    <header>
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary">العودة إلى الرئيسية</a>
                </div>
                <div>
                    <img src="<?php echo e(asset('assets/images/logo.webp')); ?>" alt="Rosemary Organic Logo">
                </div>
                <div class="d-flex" id="timer">
                    <div class="timerTitle">
                        ينتهي العرض بعد
                    </div>
                    <div class="d-flex gap-2 flex-grow-1">
                        <div id="second" class="timer">
                            <div class="time"></div>
                            <div class="timeLabel">seconds</div>
                        </div>
                        <div id="minute" class="timer">
                            <div class="time"></div>
                            <div class="timeLabel">minutes</div>
                        </div>
                        <div id="hour" class="timer">
                            <div class="time"></div>
                            <div class="timeLabel">hours</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section class="my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 order-md-2">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3 class="mb-0">معلومات الشحن</h3>
                        </div>
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            
                            <form action="<?php echo e(route('checkout.process', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3">
                                        <label for="first_name" class="form-label">الاسم</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e(old('first_name')); ?>" required>
                                    </div>
                                    
                                    <!--<div class="col-md-6 mb-3">-->
                                    <!--    <label for="last_name" class="form-label">الاسم الأخير</label>-->
                                    <!--    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e(old('last_name')); ?>" required>-->
                                    <!--</div>-->
                                </div>
                                
                                <!--<div class="mb-3">-->
                                <!--    <label for="email" class="form-label">البريد الإلكتروني</label>-->
                                <!--    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required>-->
                                <!--</div>-->
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">رقم الهاتف</label>
                                    <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="color" class="form-label">اختاري اللون</label>
                                    <input type="text" class="form-control" id="color" name="color" value="<?php echo e(old('color')); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="country" class="form-label">البلد</label>
                                    <input type="text" class="form-control" id="country" name="country" value="<?php echo e(old('country', 'مصر')); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="street_address" class="form-label">العنوان</label>
                                    <input type="text" class="form-control" id="street_address" name="street_address" value="<?php echo e(old('street_address')); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="apartment" class="form-label">الشقة/المبنى (اختياري)</label>
                                    <input type="text" class="form-control" id="apartment" name="apartment" value="<?php echo e(old('apartment')); ?>">
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="city" class="form-label">المدينة</label>
                                        <input type="text" class="form-control" id="city" name="city" value="<?php echo e(old('city')); ?>" required>
                                    </div>
                                    
                                    <div class="col-md-4 mb-3">
                                        <label for="region" class="form-label">المنطقة/المحافظة</label>
                                        <select class="form-select" id="region" name="region" required>
                                            <option value="" selected disabled>اختر المحافظة</option>
                                            <option value="القاهرة" <?php echo e(old('region') == 'القاهرة' ? 'selected' : ''); ?>>القاهرة</option>
                                            <option value="الجيزة" <?php echo e(old('region') == 'الجيزة' ? 'selected' : ''); ?>>الجيزة</option>
                                            <option value="الإسكندرية" <?php echo e(old('region') == 'الإسكندرية' ? 'selected' : ''); ?>>الإسكندرية</option>
                                            <option value="الإسماعيلية" <?php echo e(old('region') == 'الإسماعيلية' ? 'selected' : ''); ?>>الإسماعيلية</option>
                                            <option value="أسوان" <?php echo e(old('region') == 'أسوان' ? 'selected' : ''); ?>>أسوان</option>
                                            <option value="أسيوط" <?php echo e(old('region') == 'أسيوط' ? 'selected' : ''); ?>>أسيوط</option>
                                            <option value="الأقصر" <?php echo e(old('region') == 'الأقصر' ? 'selected' : ''); ?>>الأقصر</option>
                                            <option value="البحر الأحمر" <?php echo e(old('region') == 'البحر الأحمر' ? 'selected' : ''); ?>>البحر الأحمر</option>
                                            <option value="البحيرة" <?php echo e(old('region') == 'البحيرة' ? 'selected' : ''); ?>>البحيرة</option>
                                            <option value="بني سويف" <?php echo e(old('region') == 'بني سويف' ? 'selected' : ''); ?>>بني سويف</option>
                                            <option value="بورسعيد" <?php echo e(old('region') == 'بورسعيد' ? 'selected' : ''); ?>>بورسعيد</option>
                                            <option value="جنوب سيناء" <?php echo e(old('region') == 'جنوب سيناء' ? 'selected' : ''); ?>>جنوب سيناء</option>
                                            <option value="الدقهلية" <?php echo e(old('region') == 'الدقهلية' ? 'selected' : ''); ?>>الدقهلية</option>
                                            <option value="دمياط" <?php echo e(old('region') == 'دمياط' ? 'selected' : ''); ?>>دمياط</option>
                                            <option value="سوهاج" <?php echo e(old('region') == 'سوهاج' ? 'selected' : ''); ?>>سوهاج</option>
                                            <option value="السويس" <?php echo e(old('region') == 'السويس' ? 'selected' : ''); ?>>السويس</option>
                                            <option value="الشرقية" <?php echo e(old('region') == 'الشرقية' ? 'selected' : ''); ?>>الشرقية</option>
                                            <option value="شمال سيناء" <?php echo e(old('region') == 'شمال سيناء' ? 'selected' : ''); ?>>شمال سيناء</option>
                                            <option value="الغربية" <?php echo e(old('region') == 'الغربية' ? 'selected' : ''); ?>>الغربية</option>
                                            <option value="الفيوم" <?php echo e(old('region') == 'الفيوم' ? 'selected' : ''); ?>>الفيوم</option>
                                            <option value="القليوبية" <?php echo e(old('region') == 'القليوبية' ? 'selected' : ''); ?>>القليوبية</option>
                                            <option value="قنا" <?php echo e(old('region') == 'قنا' ? 'selected' : ''); ?>>قنا</option>
                                            <option value="كفر الشيخ" <?php echo e(old('region') == 'كفر الشيخ' ? 'selected' : ''); ?>>كفر الشيخ</option>
                                            <option value="مطروح" <?php echo e(old('region') == 'مطروح' ? 'selected' : ''); ?>>مطروح</option>
                                            <option value="المنوفية" <?php echo e(old('region') == 'المنوفية' ? 'selected' : ''); ?>>المنوفية</option>
                                            <option value="المنيا" <?php echo e(old('region') == 'المنيا' ? 'selected' : ''); ?>>المنيا</option>
                                            <option value="الوادي الجديد" <?php echo e(old('region') == 'الوادي الجديد' ? 'selected' : ''); ?>>الوادي الجديد</option>
                                        </select>
                                    </div>
                                    
                                    <!--<div class="col-md-4 mb-3">-->
                                    <!--    <label for="postal_code" class="form-label">الرمز البريدي</label>-->
                                    <!--    <input type="text" class="form-control" id="postal_code" name="postal_code" value="<?php echo e(old('postal_code')); ?>" required>-->
                                    <!--</div>-->
                                </div>
                                
                                <div class="mb-3">
                                    <label for="notes" class="form-label">ملاحظات (اختياري)</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo e(old('notes')); ?></textarea>
                                </div>
                                
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="terms" required>
                                    <label class="form-check-label" for="terms">
                                    أوافق على مصاريف الشحن
                                    </label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary btn-lg">إتمام الطلب</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 order-md-1">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3 class="mb-0">ملخص الطلب</h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-4">
                                <?php if($product->hasMedia('product_images')): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->getFirstMedia('product_images')->id . '/' . $product->getFirstMedia('product_images')->file_name)); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid" style="max-width: 100px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/911111.webp')); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid" style="max-width: 100px;">
                                <?php endif; ?>
                                
                                <div class="ms-3">
                                    <h4><?php echo e($product->name); ?></h4>
                                    <h5 class="text-primary"><?php echo e($product->price); ?> ج.م</h5>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <p><?php echo nl2br(e($product->description)); ?></p>
                            </div>
                            
                            <div class="mb-0">
                                <div class="d-flex justify-content-between">
                                    <strong>السعر النهائي:</strong>
                                    <strong><?php echo e($product->price); ?> ج.م</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="copyright text-start py-3">
                All rights reserved
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH /home/u364207981/domains/rosemaryorganic.com/public_html/resources/views/checkout.blade.php ENDPATH**/ ?>